from partie import Partie 
from vehicule import Vehicule
from fenetre_partie import FenetrePartie
from tkinter import*
from gestion_son import Musique





    


test=Tk()
Musique()

#laPremierePartie=FenetrePartie(lesVehicules)
laPremierePartie=FenetrePartie(11,test)
laPremierePartie.afficher()

