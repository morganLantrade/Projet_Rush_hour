from Vehicule import*

class Partie():
	
	          
	def __init__(self,vehicules):
		self.vehicules = { v.id : v for v in vehicules}
		self.matrix=[ [0]*6 for _ in range(6)]
		for vehicule in self.vehicules.values():
			(y,x)=vehicule.coord
			(xD,yD)=Vehicule.DIRECTIONS["Bas" if vehicule.orientation=="Vertical" else "Droite"]
			for i in range(vehicule.lg):
				self.matrix[y+i*yD][x+i*xD]=vehicule.id
		self.selected=None # ID selection
		self.moves=0
		#self.chrono
		#self.difficulty
		
	


	def estGagnee(self):
		return self.vehicules[1].coord==(3,4)

	def addMove(self):
		self.moves+=1
	


	
	#update borneMin et borneSup du vehicule selected
	def updatePossibleMove(self):
		vehicule=self.vehicules[self.selected]
		(y,x)=vehicule.coord
		vehicule.possibleMove=set()
		if vehicule.orientation=="Horizontal":
			borneMin=x
			borneMax=x+vehicule.lg-1
			while borneMin-1 >=0 and self.matrix[y][borneMin-1]==0:
				borneMin-=1
				vehicule.possibleMove.add((y,borneMin))
				
			while borneMax+1 <=5 and self.matrix[y][borneMax+1]==0:
				borneMax+=1
				vehicule.possibleMove.add((y,borneMax-vehicule.lg))
				
		else:
			borneMin=y
			borneMax=y+vehicule.lg-1
			while borneMin-1 >=0 and self.matrix[borneMin-1][x]==0:
				borneMin-=1
				vehicule.possibleMove.add((borneMin,x))
			while borneMax+1 <=5 and self.matrix[borneMax+1][x]==0:
				borneMax+=1
				vehicule.possibleMove.add((borneMax-vehicule.lg,x))
				

    
		
	def updateMatrix(self,coord):
		vehicule=self.vehicules[self.selected]
		vehicule.coord=coord
		(y,x)=vehicule.coord
		(xD,yD)=Vehicule.DIRECTIONS["Bas" if vehicule.orientation=="Vertical" else "Droite"]
		for i in range(6):
			for j in range(6):
				if self.matrix[i][j]==self.selected:
					self.matrix[i][j]=0
		for i in range(vehicule.lg):
			self.matrix[y+i*yD][x+i*xD]=vehicule.id
		
			

	def __str__(self):
		return '\n'.join(str(self.matrix[i])for i in range(6))


