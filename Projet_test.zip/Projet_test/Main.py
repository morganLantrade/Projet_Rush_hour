from Partie import*
from Vehicule import*
from AfficherPartie import*

lesVehicules= [ Vehicule((3,1),"Horizontal",2), #1
		    	Vehicule((0,3),"Horizontal",2), #2
			    Vehicule((1,3),"Horizontal",2), #3
			    Vehicule((1,0),"Vertical",3), #4 
			    Vehicule((5,0),"Horizontal",3), #5
				Vehicule((1,2),"Vertical",2), #6
				Vehicule((2,3),"Vertical",3), #7
				Vehicule((2,5),"Vertical",3) #8
				]

test=AfficherPartie(lesVehicules)
test.show()

