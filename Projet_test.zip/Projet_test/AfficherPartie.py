from tkinter import *
from Partie import*
from Vehicule import*


CASE=120 # a modifier
BOARD=CASE//20
WIDTH=7*CASE+BOARD
HEIGHT=6*CASE+BOARD

COLORS=["white",'red',"yellow","blue","green","orange",
"purple","grey","light green","salmon","brown","pink","dark green"]

class AfficherPartie(Partie):
	vector=(0,0)
	origin=(0,0)
	selectedCoord=(0,0)
	def __init(self,vehicules):
		super().__init__(vehicules)
				
		
		
	#return le coin sup gauche,inf droit et couleur du rectangle representant la voiture
	def vehiculeIntoRect(self,vehicule):
		def selectedIntoRect(self,A,B,C):
			vehicule=self.vehicules[self.selected]
			a1,a2=A
			b1,b2=B
			v1,v2=self.vector
			if vehicule.orientation=="Vertical":
				move=((a2+v2)//CASE,a1//CASE) 
				if move in vehicule.possibleMove:
					a2+=v2
					b2+=v2
				elif vehicule.possibleMove:
					a2=5+CASE*(max(vehicule.possibleMove)[0]+1 if v2>0 else min(vehicule.possibleMove)[0])
					b2=a2+CASE*vehicule.lg
			else:
				move=(a2//CASE,(a1+v1)//CASE)
				if move in vehicule.possibleMove:
					a1+=v1
					b1+=v1
				elif vehicule.possibleMove:
					a1=5+CASE*(max(vehicule.possibleMove)[1]+1 if v1>0 else min(vehicule.possibleMove)[1])
					b1=a1+CASE*vehicule.lg
			self.selectedCoord= (a2//CASE+(1 if (a2%CASE>CASE//2) else 0),a1//CASE + (1 if (a1%CASE>CASE//2) else 0) )
			return ((a1,a2),(b1,b2),C)

		(i,j)=vehicule.coord
		(iD,jD)=Vehicule.DIRECTIONS["Bas" if vehicule.orientation=="Vertical" else "Droite"]
		(a1,a2)=5+j*CASE,5+i*CASE
		if (jD==0):
			B=b1,b2=(a1+CASE*vehicule.lg,a2+CASE) #mouvement lateral
		else:
			B=b1,b2=(a1+CASE,a2+CASE*vehicule.lg) #mouvement horizontal
		C=COLORS[vehicule.id] if vehicule.id!=self.selected else "black"
		if vehicule.id==self.selected:
			return selectedIntoRect(self,(a1,a2),B,C)
		return ((a1,a2),B,C)
	
	
		

		
	def drawFleche(self,cnv):
		cnv.create_line((6*CASE+CASE//4,3*CASE+CASE//2),(7*CASE-CASE//4,3*CASE+CASE//2),width=CASE//5,arrow='last',fill="green")

	def drawVehicules(self,cnv):
		for vehicule in self.vehicules.values():
			a,b,c= self.vehiculeIntoRect(vehicule)
			if vehicule.id!=self.selected:
				cnv.create_rectangle(a,b,fill=c,outline=c )
			else:
				cnv.create_rectangle(a,b,fill="black")
	
	

	def drawGrille(self,cnv):
		#return sup gauche et in droit d'une case		
		def coordIntoRect(i,j):
			A=(a1,a2)=(5+i*CASE,5+j*CASE)
			B=(a1+CASE,a2+CASE)
			return (A,B)
		rects= [ (coordIntoRect(i,j),str(self.matrix[j][i])) for i in range(6) for j in range(6)]
		for (a,b),c in rects:
			cnv.create_rectangle(a,b)
			cnv.create_text(a[0]+CASE//2,a[1]+CASE//2,text=c,font=('arial',CASE//3,'bold'),fill="black" if int(c)!=self.selected or int(c)==0  else "white")
			
	def drawMove(self,cnv):
		cnv.create_text(6*CASE+CASE//2,CASE,text="Moves",font=('arial',CASE//6,'bold'),fill="black")
		cnv.create_text(6*CASE+CASE//2,CASE+CASE//3,text=str(self.moves),font=('arial',CASE//3,'bold'),fill="black")

	def drawChrono(self,cnv):
		cnv.create_text(6*CASE+CASE//2,2*CASE,text="Time",font=('arial',CASE//5,'bold'),fill="black" )
		cnv.create_text(6*CASE+CASE//2,2*CASE+CASE//3,text="00:00",font=('arial',CASE//8,'bold'),fill="black" )

	def drawVictory(self,cnv):
		cnv.create_text(6*CASE+CASE//2,5*CASE,text="Victory",font=('arial',CASE//8,'bold'),fill="black")
		cnv.create_text(6*CASE+CASE//2,5*CASE+CASE//3,text=str(self.estGagnee()),font=('arial',CASE//8,'bold'),fill="black" )
	

	def draw(self,cnv):
		cnv.delete("all")
		self.drawVehicules(cnv)
		self.drawGrille(cnv)
		self.drawFleche(cnv)
		self.drawMove(cnv)
		self.drawVictory(cnv)
		self.drawChrono(cnv)

	
	def show(self):
		def selection(event):
			if 0<= event.y//CASE<6 and 0 <= event.x//CASE <6:
				idV=self.matrix[event.y//CASE][event.x//CASE]
				self.selected=idV
			self.origin=(event.x,event.y)
			if self.selected and self.selected!=0:
				self.updatePossibleMove()
				self.draw(cnv)

		def updateMove(event):
			AfficherPartie.vector=(event.x-self.origin[0],event.y-self.origin[1])
			cnv.delete('all')
			self.draw(cnv)

		def unselect(event):
			if self.selected and self.selectedCoord!=self.vehicules[self.selected].coord and self.selected!=0:
				self.addMove()
				self.updateMatrix(self.selectedCoord)
				self.updatePossibleMove()
			self.selected=None
			self.draw(cnv)
			
		

		root=Tk()
		cnv=Canvas(root,width=WIDTH,height=HEIGHT,bg="ivory")
		cnv.pack(side="left",padx=0,pady=0)
		root.bind('<Button-1>',selection)
		root.bind('<B1-Motion>',updateMove)
		root.bind('<ButtonRelease-1>',unselect)
		root.title("Partie")
		self.draw(cnv)
		root.mainloop()


