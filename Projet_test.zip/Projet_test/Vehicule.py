class Vehicule:
	DIRECTIONS= {"Bas":(0,1), "Haut" : (0,-1),"Droite":(1,0),"Gauche":(-1,0)}
	ORIENTATIONS=["Vertical","Horizontal"]
	ID=1
				
	def __init__(self,coord,orientation,lg):
		self.id=Vehicule.ID
		Vehicule.ID+=1 
		self.coord=coord  
		self.orientation=orientation
		self.lg=lg
		self.possibleMove=set()
		


	def __str__(self):
		answer= f'Un vehicule de longueur {self.lg} '
		answer+=f'placé en {self.coord} orienté  {self.orientation} '
		answer+=f'possibles moves {self.possibleMove}'
		return answer
	def __eq__(self,other):
		return isinstance(other,Vehicule) and self.id==other.id

		
