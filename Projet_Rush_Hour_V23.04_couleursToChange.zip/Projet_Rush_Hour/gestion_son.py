import pygame


 
class Musique:
    etat_musique=0
    musique=None
   
    def __init__(self):
        pygame.init()
        Musique.musique=pygame.mixer.Sound("assets/sons/musique.wav") 
        Musique.musique.set_volume(0.025)
        Musique.musique.play(-1,0,8000)

    
    @staticmethod
    def pause():
        pygame.mixer.pause()
        Musique.etat_musique=2

    @staticmethod
    def unpause():
        pygame.mixer.unpause()
        Musique.etat_musique=0
        
    @staticmethod
    def stop():
        pygame.quit()

