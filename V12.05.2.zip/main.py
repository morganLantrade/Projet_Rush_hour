from partie import Partie 
from vehicule import Vehicule
from fenetre_partie import FenetrePartie
from tkinter import*
from gestion_son import Musique







    
       


'''WARNING : double click peut entrainer des bugs '''

lesVehicules= [ Vehicule((3,1),"H",2), #1
                Vehicule((0,3),"H",2), #2
                Vehicule((1,3),"H",2), #3
                Vehicule((1,0),"V",3), #4 
                Vehicule((5,0),"H",3), #5
                Vehicule((1,2),"V",2), #6
                Vehicule((2,3),"V",3), #7
                Vehicule((2,5),"V",3) #8
                ]

laMatrice=[[2, 2, 0, 0, 0, 0],
           [0, 3, 12, 12, 10, 9],
           [0, 3, 1, 1, 10, 9], 
           [0, 4, 11, 11, 10, 9],
           [0, 4, 6, 7, 8, 8], 
           [5, 5, 6, 7, 0, 0]]

test=Tk()

Musique()
Musique.pause()

#laPremierePartie=FenetrePartie(lesVehicules)
laPremierePartie=FenetrePartie(0,test)
laPremierePartie.afficher()

