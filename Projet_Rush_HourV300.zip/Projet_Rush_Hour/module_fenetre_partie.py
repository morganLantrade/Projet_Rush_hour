from tkinter import *
from module_partie import Partie
from module_vehicule import Vehicule
from PIL import Image,ImageTk
from timeit import default_timer
from copy import deepcopy










class FenetrePartie(Partie):
    ''' La classe FenetrePartie  hérite de la classe Partie et représente
    graphiquement le plateau de jeu en lancant une fenetre Tkinter 
    Elle sera capable de gérer les évènements.

        Nouveaux attributs :

        List(Vehicule) ou int[6][6]  copie : permet de recommencer une partie
        int selected : représente l'id du véhicule selectionné ( par la souris ) 
        (int,int) vecteur_deplacement 
        (int,int) clic_origine 
        (int,int) coord_selected 
        { vehicule.id : Image } images des véhicules
        boolean souris_sur_tag : permet de modifier la couleur de certain widgets du canevas
        boolean pause
        boolean redimensionnee
        float : chrono = timer actuel
        float : debut = timer début partie
        float : timer_pause= timer mémorisation de la pause
        int cpt_voiture : permet de choisir parmis les différentes voitures proposées dans le fichier
        int cpt_camion : permet de choisir parmis les différents camions proposés dans le fichier
        int : width :largeur canevas
        int : height :height hauteur canevas
        int : board_x :taille du board en largeur
        int : board_y :taille du board en hauteur
        int : case :taille d'une case


    '''
    etat_son=0
        
    def __init__(self,vehicules,master,size=(800,600)):
        self.copie=deepcopy(vehicules) 
        super().__init__(vehicules)
        self.vecteur_deplacement=(0,0)
        self.clic_origine=(0,0)
        self.coord_selected=(0,0)
        self.selected=None
        self.souris_sur_tag=None
        self.pause=True
        #DICTIONNAIRES D'IMAGES,DE SONS et de BOUTONS(fonctions)
        self.images={}
        self.sons=[None]*4
        self.nb_voiture=5
        self.nb_camion=3
               
        # TIMER
        self.chrono=0
        self.debut=default_timer()
        self.timer_pause=0 
                
        ## DIMENSIONS FENETRE
        self.width=size[0]
        self.height=size[1]
        self.board_x=self.width//20
        self.board_y=self.height//40
        self.case=int(self.width/8.4)
        self.redimensionnee=False
        
        #LANCER FENETRE ET LIER SES EVENTS
        self.root=master
        self.canvas=Canvas(self.root,width=self.width,height=self.height,bg="grey")
        self.canvas.pack(side="top",padx=0,pady=0)
        self.root.bind('<Button-1>',self.selection)
        self.root.bind('<B1-Motion>',self.updateMove)
        self.root.bind('<ButtonRelease-1>',self.unselect)
        self.root.bind('<Motion>' , self.mouse_on )
        self.root.bind('<Configure>',self.resize)
        self.root.bind('<Key>',self.pressed)
        self.root.title("Rush Hour")
        self.root.geometry(f'{self.width}x{self.height}+{self.root.winfo_screenwidth()//2-self.width//2}+{self.root.winfo_screenheight()//2-self.height//2}')
        self.root.minsize(400,300)
        


        
    #############################################################################################################################
    #############################################################################################################################
    #####                    EVENT HANDLERS                                                                                   ###
    #############################################################################################################################
    #############################################################################################################################
    
    def selection(self,event):
        ''' si le click est dans la grille on met a jour l'id selected
        on met a jour clic_origine
        et on redessin car la couleur du vehicule selected change '''
        tag=self.canvas.find_closest(event.x,event.y)
        leTag=self.lireTag(tag)
        if len(leTag)>0:
            #Cas d'un vehicule selectionné
            if leTag[0]=="V" and not self.pause and not self.est_gagnee:
                self.clic_origine=(event.x,event.y)
                self.vecteur_deplacement=(0,0)
                v=self.vehicules[int(leTag[1:])]
                self.selected=v.id
                self.coord_selected=v.coord

            ##on appelle la fonction selectionnee
            self.draw()

    
    def updateMove(self,event):
        ''' lorsque la souris bouge avec le click  gauche activé :
            on met a jour le vecteur_deplacement
            et on redessine'''
        
        self.vecteur_deplacement=(event.x-self.clic_origine[0],event.y-self.clic_origine[1])
        self.draw()
        

    def unselect(self,event):
        '''lorsqu'on lache le click gauche de la souris :
                -on remet les attributs par defauts:
                vecteur_deplacement,selected

                -on met a jour la matrice selon le mouvement effectué

                -on incrémente move
        '''
        if self.selected and self.coord_selected!=self.vehicules[self.selected].coord :
            self.addMove()
            self.updateMatrice(self.vehicules[self.selected],self.coord_selected)
            self.est_gagnee=self.estGagnee()

            
        self.vecteur_deplacement=(0,0)
        self.selected=None
        self.draw()



    
    
    def resize(self,event):
        '''redimensionne le canvas par rapport a la fenetre met en mode pause'''
        #On passe on en mode pause mais on redimensionne exepté pour le début de la partie.
        if event.width!=self.width :
            self.pause=True
            self.redimensionnee=True
            W=self.root.winfo_width()
            H=self.root.winfo_height()
            self.width=W
            self.height=int(W*3/4)
            if self.height>H:
                self.height=H
                self.width=int(self.height*4/3)
            # on redimensionne
            self.canvas.config(width=self.width,height=self.height)
            self.board_x=self.width//20
            self.board_y=self.height//40
            self.case=int(self.width/8.4)
            self.draw()



    
    def mouse_on(self,event):
        '''modifie les couleurs des widgets selon la position de la souris'''
        if self.redimensionnee:
            self.redimensionner()
        tag=self.canvas.find_closest(event.x,event.y)
        leTag=self.lireTag(tag)
        if len(leTag)>0:
            self.souris_sur_tag=leTag
            
        else:
            self.souris_sur_tag=None
        self.draw()

    def pressed(self,event):
        if event.char == ' 'and not self.redimensionnee:
            self.pause=not self.pause
            self.draw()
    
    
   
    def update_chrono(self):
        '''timer calculé en fonction du début de la partie et des pauses et eventuels reset''' 
        if not self.est_gagnee and not(self.pause):
            now=self.chrono=default_timer()-self.timer_pause-self.debut
        else:
            self.timer_pause=default_timer()-self.chrono-self.debut
        self.draw()
        self.root.after(1000,self.update_chrono)

    
    def redimensionner(self):
        '''redimensionne la fenetre et toutes ses dimensions et recharge les images '''
        self.redimensionnee=False
        self.update_chrono()
        W=self.root.winfo_width()
        H=self.root.winfo_height()
        self.width=W
        self.height=int(W*3/4)
        if self.height>H:
            self.height=H
            self.width=int(self.height*4/3)
        # on redimensionne
        self.canvas.config(width=self.width,height=self.height)
        self.board_x=self.width//20
        self.board_y=self.height//40
        self.case=int(self.width/8.4)
        self.load_images_Vehicules()
        self.load_images_Menu()
        self.draw()
   
    
    def lireTag(self,id_tag):
        '''retourne le tag de l' id_tag_ sur le canvas'''
        return self.canvas.itemconfig(id_tag)['tags'][-1][:-8]


    #############################################################################################################################
    #############################################################################################################################
    #####                    METHODES LIEES AUX COORDONNEES VEHICULE ET PLATEAU                                               ###
    #############################################################################################################################
    #############################################################################################################################
    
    def coordFrame_coordMatrice(self,x,y):
        ''' retourne les coordonnées (i,j) de la matrice selon les coordonnées
        (x,y) de la fenetre  '''
        (i,j)=((y-self.board_y)//self.case,(x-self.board_x)//self.case)
        return (i,j)

        
        
    #return le coin sup gauche,inf droit et couleur du rectangle representant la voiture
    def vehiculeIntoRect(self,vehicule):
        ''' Retourne selon les coordonnées du vehicule dans la matrice et la taille self.case:
        A : les coordonnées du coin sup gauche dans la fenetre
        B : les coordonnées du in droit dans la fenetre  
                
        Pour ensuite créer le rectangle dans le canvas '''      
        (y,x)=vehicule.coord
        (xD,yD)=Vehicule.DIRECTIONS["Bas" if vehicule.orientation=="V" else "Droite"]
        (x,y)=(self.board_x+x*self.case,self.board_y+y*self.case)   
        return (x,y)
    
    #########################
    #TO DO 
    #Deplacer les rectangles au lieu de clear canvas et redessiner par desssus
    #########################
    def selectedIntoRect(self):
        ''' Retourne les nouvelles coordonnées du véhicule selectionné selon le mouvement de la souris
        et gère les collisions '''
        vehicule=self.vehicules[self.selected]
        (aX,aY)= self.vehiculeIntoRect(vehicule)
        vX,vY=self.vecteur_deplacement
        possible_move=self.vehiculePossibleMove(vehicule)
        if vehicule.orientation=="V":
            try_move=self.coordFrame_coordMatrice(aX,aY+vY)  # coord du mouvement d'arrivée dans la matrice
            if try_move in possible_move :
                aY+=vY
            elif possible_move: 
                
                # prend le min ou le max des moves possibles comme collision
                aY=self.board_y+self.case*(max(possible_move)[0]+1 if vY>=0 else min(possible_move)[0]) 
                
        else:
            try_move=self.coordFrame_coordMatrice(aX+vX,aY)  # coord du mouvement d'arrivée dans la matrice
            if try_move in possible_move:
                aX+=vX
            elif possible_move:
                # prend le min ou le max des moves possibles comme collision
                aX=self.board_x+self.case*(max(possible_move)[1]+1 if vX>=0 else min(possible_move)[1])
                
        #determine les coordonnées de la matrice pour lesquelles l'arriere du Vehicule est le plus proche
        self.coord_selected=( (aY-self.board_y)//self.case + int((aY-self.board_y)%self.case>self.case/2),(aX-self.board_x)//self.case+int((aX-self.board_x)%self.case>self.case/2))
        
        return (aX,aY)


    #############################################################################################################################
    #############################################################################################################################
    #####                    METHODES LIEES AUX DATA                                                                          ###
    #############################################################################################################################
    #############################################################################################################################
    

    
    def load_images_Vehicules(self):
        '''Met a jour le dictionnaire d'image'''
        version_voiture=0
        version_camion=0
        for id in self.vehicules.keys():
            v=self.vehicules[id]
            width= self.case if v.orientation=="V" else self.case*v.lg
            height=self.case if v.orientation=="H" else self.case*v.lg
            
            if id!=1:
                #Image selon la type de vehicule
                img=Image.open(f'assets/vehicules/{v.orientation}{v.lg} N{1+(version_voiture if v.lg==2 else version_camion)}.png')
                img=img.resize((width,height))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[str(id)]=img
                #sa version selectionnée
                img=Image.open(f'assets/vehicules/{v.orientation}{v.lg}S N{1+(version_voiture if v.lg==2 else version_camion)}.png')
                img=img.resize((width,height))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[str(id)+"S"]=img
                version_voiture=(version_voiture+int(v.lg==2))%self.nb_voiture
                version_camion=(version_camion+int(v.lg==3))%self.nb_camion
                
            elif id==1 :
                #Image vehicule principal
                img=Image.open(f'assets/vehicules/P2.png')
                img=img.resize((width,height))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[str(id)]=img
                 #sa version selectionnée
                img=Image.open(f'assets/vehicules/P2S.png')
                img=img.resize((self.case*2,self.case))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[str(id)+"S"]=img
        
    '''met a jour la liste d'images son'''
    def load_images_Menu(self):
        for i in range(4):
             img=Image.open(f'assets/icon son/son{i}.png')
             img=img.resize((self.width//15,self.height//12))
             img =ImageTk.PhotoImage(img.convert("RGBA"))
             self.sons[i]= img       
             

        img=Image.open(f'assets/icon reglage/reg.png')
        img=img.resize((self.width//14,self.height//11))
        img =ImageTk.PhotoImage(img.convert("RGBA"))
        self.images['reg']= img 

        img=Image.open(f'assets/icon reglage/regS.png')
        img=img.resize((self.width//14,self.height//11))
        img =ImageTk.PhotoImage(img.convert("RGBA"))
        self.images['regS']= img 


    #############################################################################################################################
    #############################################################################################################################
    #####                    METHODES DE DRAW                                                                                 ###
    #############################################################################################################################
    #############################################################################################################################
    

    def draw(self):
        self.canvas.delete("all")
        self.drawGrille()
        self.drawInfo()
        self.drawMenu()
        if not(self.redimensionnee):
            self.drawVehicules()
            
    def drawVehicules(self):
        '''recupere les positions des images et  les affiche'''
        
        for vehicule in self.vehicules.values():
            if self.selected and vehicule.id==self.selected and self.vecteur_deplacement!=(0,0) :
                (x,y)=self.selectedIntoRect()
            else:
                (x,y)= self.vehiculeIntoRect(vehicule) 
            
            self.canvas.create_image(x,y,image=self.images[str(vehicule.id)+("S" if self.selected and vehicule.id==self.selected else "")],anchor="nw",tags=f'V{vehicule.id}')
    

    def drawGrille(self):
        def coordIntoRect(i,j):
            '''retourne le coin sup gauche et inf droit d'une self.case de coordonnée (i,j) de la matrice'''
            (x,y)=(self.board_x+j*self.case,self.board_y+i*self.case)
            if self.pause:
                 color="grey26" if (i+j)%2==0 else "gray20"
            else:
                 color="LightYellow2" if (i+j)%2==0 else "sienna4"
            return ((x,y),(x+self.case,y+self.case),color)
        rects= [ coordIntoRect(i,j) for i in range(6) for j in range(6)]
        
        for (A,B,C) in rects:
            self.canvas.create_rectangle(A,B,fill=C,outline=C)
        '''#arrivée A REFAIRE 
        arrivée=((x1,y1),(x2,y2),_)=coordIntoRect(3,5)
        self.canvas.create_rectangle((x1+2*self.case,y1+2),(x2+2*self.case,y2-2),fill="grey26" if self.pause else "dimgray",outline="grey26" if self.pause else "dimgray")
        self.canvas.create_rectangle((x1+self.case,y1+2),(x2+self.case,y2-2),fill="gray20" if self.pause else "silver",outline="gray20" if self.pause else "silver")'''


    #def drawFleche(self):
        #self.canvas.create_line((7*self.case+self.case//3,self.board_y+3*self.case+self.case//2),(8.5*self.case-self.case//2,self.case+3*self.case+self.case//2),width=self.case//5,arrow='last',fill="green" if self.estGagnee() else "red")

    def drawLevel(self):
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+4.55*self.case+self.case//6,text="Level",font=('arial',self.case//6,'bold'),fill="black")
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+4.55*self.case+3*self.case//7,text="***",font=('arial',self.case//8,'bold'),fill="black")

    def drawStage(self):
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+4*self.case+self.case//6,text="Stage",font=('arial',self.case//6,'bold'),fill="black")
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+4*self.case+3*self.case//7,text=str(17),font=('arial',self.case//8,'bold'),fill="black")

    def drawMove(self):
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+5*self.case+self.case//6,text="Moves",font=('arial',self.case//6,'bold'),fill="black")
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+5*self.case+3*self.case//8,text=str(self.moves),font=('arial',self.case//8,'bold'),fill="black")

    def drawChrono(self):
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+5.45*self.case+self.case//6,text="Time",font=('arial',self.case//6,'bold'),fill="black" )
        self.canvas.create_text(7*self.case+self.case//2,self.board_y+5.45*self.case+3*self.case//7,text=f'{int(self.chrono//60)} mn {int(self.chrono%60)} s',font=('arial',self.case//8,'bold'),fill="black" )

    

    def drawMenu(self):
        def drawTriangle(x,y,size,orientation,couleur,tag):
            if orientation=="droite":
                return self.canvas.create_polygon(x,y,x+size,y+size/2,x,y+size,fill=couleur,tags=tag)
            else:
                return self.canvas.create_polygon(x,y+size/2,x+size,y+size,x+size,y,fill=couleur,tags=tag)

        
        def drawSon(x,y):
            surligner= self.souris_sur_tag and self.souris_sur_tag=='bouton_son'
            self.canvas.create_image(x,y,image=self.sons[(self.etat_son if not(surligner) else self.etat_son+1)],anchor="nw",tags=f'bouton_son')
            
        def drawReglage(x,y):
            surligner= self.souris_sur_tag and self.souris_sur_tag=='bouton_reglage'
            self.canvas.create_image(x,y,image=self.images[('reg' if not surligner else 'regS')],anchor="nw",tags=f'bouton_reglage')
       



        self.canvas.create_rectangle(6*self.case+1.7*self.board_x,self.board_y,7.5*self.case+1.7*self.board_x,self.board_y+3*self.case,fill="peru")
        width_menu=1.3*self.case
        height_menu=3*self.case
        board_x_menu=width_menu/10
        board_y_menu=height_menu/20
        height_bouton=int(self.case/1.54)-board_y_menu/2
        x=6*self.case+1.7*self.board_x+board_x_menu
        y=self.board_y+board_y_menu/1.3
        bouton_reset=self.canvas.create_rectangle(x,y,x+width_menu-board_x_menu/2,y+height_bouton,fill="white" if self.souris_sur_tag and self.souris_sur_tag==f'bouton_reset' else "cadetblue",tags=f'bouton_reset')
        text_bouton_reset=self.canvas.create_text(x+width_menu/2.2,y+height_bouton/2.1,text="Reset",font=('arial',self.case//4,'bold'),fill="black",tags='bouton_reset')
        bouton_avancer=drawTriangle(x+board_x_menu+self.case/1.6,y+1.5*height_bouton,self.case/2.4,"droite","grey28" if self.souris_sur_tag and self.souris_sur_tag=='bouton_avancer' else 'black','bouton_avancer')
        bouton_retour=drawTriangle(x+board_x_menu/4,y+1.5*height_bouton,self.case/2.4,"gauche",'grey28' if self.souris_sur_tag and self.souris_sur_tag=='bouton_retour' else 'black','bouton_retour')
        bouton_indice=self.canvas.create_rectangle(x,y+(board_y_menu+height_bouton)*3,x+width_menu-board_x_menu/2,y+3*(board_y_menu+height_bouton)+height_bouton,fill="white" if self.souris_sur_tag and self.souris_sur_tag==f'bouton_indice' else "cadetblue",tags=f'bouton_indice')
        text_bouton_indice=self.canvas.create_text(x+width_menu/2.2,y+(board_y_menu+height_bouton)*3+height_bouton/2.1,text="Hint",font=('arial',self.case//4,'bold'),fill="black",tags='bouton_indice')
        if not(self.redimensionnee):
            drawSon(x+board_x_menu/3,y+2*(height_bouton+board_y_menu)+board_y_menu*4/10)
            drawReglage(x+width_menu/2.2,y+2*(height_bouton+board_y_menu)+board_y_menu*1/10)
            
        


    def drawInfo(self):
        self.canvas.create_rectangle(6*self.case+1.7*self.board_x,self.board_y+4*self.case,7.5*self.case+1.7*self.board_x,self.board_y+6*self.case,fill="peru" if not self.estGagnee() else "green")
        self.drawLevel()
        self.drawStage()
        self.drawMove()
        self.drawChrono()

    def drawVictory(self):
        self.canvas.create_text(7*self.case+self.case//2,5*self.case,text="Victory",font=('arial',self.case//8,'bold'),fill="black")
        self.canvas.create_text(7*self.case+self.case//2,5*self.case+self.case//3,text=str(self.est_gagnee),font=('arial',self.case//8,'bold'),fill="black" )
    

    def drawPause(self):
        (x,y)=(self.board_x+self.case*2.25,self.board_y+self.case*2)
        self.canvas.create_polygon(x,y,x+self.case*2,y+self.case,x,y+self.case*2,fill='yellow' if self.souris_sur_tag and self.souris_sur_tag=='play' else 'white',tags='play')
        







   
    
###########################################################################################################################
#############################################################################################################################
#####                    METHODES PRINCIPALE DE LA FENETRE                                                                ###
#############################################################################################################################
#############################################################################################################################
        
    '''mainloop de la fenetre Tkinter'''
    def afficher(self):
        self.load_images_Vehicules()
        self.load_images_Menu()
        self.draw()
        self.root.after(1000,self.update_chrono)
        self.root.mainloop()
    
    def quitter(self):
        self.root.destroy()

