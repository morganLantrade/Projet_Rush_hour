from tkinter import *
from module_partie import Partie
from module_vehicule import Vehicule
from PIL import Image,ImageTk








class FenetrePartie(Partie):
    ''' La classe FenetrePartie est hérite de la classe Partie et représente
    graphiquement le plateau de jeu et les différents attributs de la Partie.
    Elle sera capable de gérer les évènements.

    
        Nouveaux attributs :
        int selected : représente l'id du véhicule selectionné ( par la souris ) 
        (int,int) vector_deplacement
        (int,int) origin_click
        (int,int) selected_coord


    '''
    
    def __init__(self,vehicules,size):
        
        super().__init__(vehicules)
        self.vector_deplacement=(0,0)
        self.origin_click=(0,0)
        self.selectedCoord=(0,0)
        self.selected=None
        self.bg=None
        self.images={}


        ## DIMENSIONS FENETRE
        self.width=size[0]
        self.height=size[1]
        self.board_x=self.width//20
        self.board_y=self.height//40
        self.case=int(self.width/8.4)
    
        
        
        
    
    
    def coordFrame_coordMatrice(self,x,y):
        ''' retourne les coordonnées (i,j) de la matrice selon les coordonnées
        (x,y) de la fenetre  '''
        (i,j)=((y-self.board_y)//self.case,(x-self.board_x)//self.case)
        return (i,j)

        
        
    #return le coin sup gauche,inf droit et couleur du rectangle representant la voiture
    def vehiculeIntoRect(self,vehicule):
        ''' Retourne selon les coordonnées du vehicule dans la matrice et la taille self.case:
        A : les coordonnées du coin sup gauche dans la fenetre
        B : les coordonnées du in droit dans la fenetre  
                
        Pour ensuite créer le rectangle dans le canvas '''      
        (y,x)=vehicule.coord
        (xD,yD)=Vehicule.DIRECTIONS["Bas" if vehicule.orientation=="V" else "Droite"]
        (x,y)=(self.board_x+x*self.case,self.board_y+y*self.case)   
        return (x,y)
    
    #########################
    #TO DO 
    #Deplacer les rectangles au lieu de clear canvas et redessiner par desssus
    #########################
    def selectedIntoRect(self):
        ''' Retourne les nouvelles coordonnées du véhicule selectionné selon le mouvement de la souris
        et gère les collisions '''
        vehicule=self.vehicules[self.selected]
        (aX,aY)= self.vehiculeIntoRect(vehicule)
        vX,vY=self.vector_deplacement
        possible_move=self.vehiculePossibleMove(vehicule)
        if vehicule.orientation=="V":
            try_move=self.coordFrame_coordMatrice(aX,aY+vY)  # coord du mouvement d'arrivée dans la matrice
            if try_move in possible_move :
                aY+=vY
            elif possible_move: 
                
                # prend le min ou le max des moves possibles comme collision
                aY=self.board_y+self.case*(max(possible_move)[0]+1 if vY>0 else min(possible_move)[0]) 
                
        else:
            try_move=self.coordFrame_coordMatrice(aX+vX,aY)  # coord du mouvement d'arrivée dans la matrice
            if try_move in possible_move:
                aX+=vX
            elif possible_move:
                # prend le min ou le max des moves possibles comme collision
                aX=self.board_x+self.case*(max(possible_move)[1]+1 if vX>0 else min(possible_move)[1])
                
        #determine les coordonnées de la matrice pour lesquelles l'arriere du Vehicule est le plus proche
        self.selectedCoord=( (aY-self.board_y)//self.case + int((aY-self.board_y)%self.case>self.case//2),(aX-self.board_x)//self.case+int((aX-self.board_x)%self.case>self.case//2))
        
        return (aX,aY)

    '''Met a jour le dictionnaire d'image'''
    def load_images(self):
        for id in self.vehicules.keys():
            v=self.vehicules[id]
            width= self.case if v.orientation=="V" else self.case*v.lg
            height=self.case if v.orientation=="H" else self.case*v.lg
            if id!=1:
                img=Image.open(f'assets/{v.orientation}{v.lg}.png')
                img=img.resize((width,height))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[id]=img
            elif id==1:
                img=Image.open(f'assets/P2.png')
                img=img.resize((width,height))
                img =ImageTk.PhotoImage(img.convert("RGBA"))
                self.images[id]=img
            
                
    

        
    



    def drawVehicules(self,cnv):
        ''' met a jour le dictionnaire d'image et les affiche'''
        
        for vehicule in self.vehicules.values():
            if self.selected and vehicule.id==self.selected and self.vector_deplacement!=(0,0):
                (x,y)=self.selectedIntoRect()
            else:
                (x,y)= self.vehiculeIntoRect(vehicule) 
            cnv.create_image(x,y,image=self.images[vehicule.id],anchor="nw")
            

    
    

    def drawGrille(self,cnv):
        #return sup gauche et in droit d'une self.case       
        def coordIntoRect(i,j):
            '''retourne le coin sup gauche et inf droit d'une self.case de coordonnée (i,j) de la matrice'''
            (x,y)=(self.board_x+j*self.case,self.board_y+i*self.case)
            color="dimgray" if (i+j)%2==0 else "silver"
            return ((x,y),(x+self.case,y+self.case),color)
            
        rects= [ coordIntoRect(i,j) for i in range(6) for j in range(6)]
        
        for (A,B,C) in rects:
            cnv.create_rectangle(A,B,fill=C,outline=C)

    #def drawFleche(self,cnv):
        #cnv.create_line((7*self.case+self.case//3,self.board_y+3*self.case+self.case//2),(8.5*self.case-self.case//2,self.case+3*self.case+self.case//2),width=self.case//5,arrow='last',fill="green" if self.estGagnee() else "red")

    def drawLevel(self,cnv):
        cnv.create_text(7*self.case+self.case//2,self.board_y+4.55*self.case+self.case//6,text="Level",font=('arial',self.case//6,'bold'),fill="black")
        cnv.create_text(7*self.case+self.case//2,self.board_y+4.55*self.case+3*self.case//7,text="***",font=('arial',self.case//8,'bold'),fill="black")

    def drawStage(self,cnv):
        cnv.create_text(7*self.case+self.case//2,self.board_y+4*self.case+self.case//6,text="Stage",font=('arial',self.case//6,'bold'),fill="black")
        cnv.create_text(7*self.case+self.case//2,self.board_y+4*self.case+3*self.case//7,text=str(17),font=('arial',self.case//8,'bold'),fill="black")

    def drawMove(self,cnv):
        cnv.create_text(7*self.case+self.case//2,self.board_y+5*self.case+self.case//6,text="Moves",font=('arial',self.case//6,'bold'),fill="black")
        cnv.create_text(7*self.case+self.case//2,self.board_y+5*self.case+3*self.case//8,text=str(self.moves),font=('arial',self.case//8,'bold'),fill="black")

    def drawChrono(self,cnv):
        cnv.create_text(7*self.case+self.case//2,self.board_y+5.45*self.case+self.case//6,text="Time",font=('arial',self.case//6,'bold'),fill="black" )
        cnv.create_text(7*self.case+self.case//2,self.board_y+5.45*self.case+3*self.case//7,text="00:00",font=('arial',self.case//8,'bold'),fill="black" )

    def drawMenu(self,cnv):
        cnv.create_rectangle(6*self.case+1.7*self.board_x,self.board_y,7.5*self.case+1.7*self.board_x,self.board_y+3*self.case,fill="peru")
        width_menu=1.3*self.case
        height_menu=3*self.case
        board_x_menu=width_menu/10
        board_y_menu=height_menu/20
        height_boutton=int(self.case/1.54)-board_y_menu/2
        x=6*self.case+1.7*self.board_x+board_x_menu
        y=self.board_y+board_y_menu/1.3
        buttons=[cnv.create_rectangle(x,y+i*height_boutton+board_y_menu*i,x+width_menu-board_x_menu/2,y+(i+1)*height_boutton+board_y_menu*i,fill="cadetblue") for i in range(4)]
        return buttons


    def drawInfo(self,cnv):
        cnv.create_rectangle(6*self.case+1.7*self.board_x,self.board_y+4*self.case,7.5*self.case+1.7*self.board_x,self.board_y+6*self.case,fill="peru")
        self.drawLevel(cnv)
        self.drawStage(cnv)
        self.drawMove(cnv)
        self.drawChrono(cnv)

    def drawVictory(self,cnv):
        cnv.create_text(7*self.case+self.case//2,5*self.case,text="Victory",font=('arial',self.case//8,'bold'),fill="black")
        cnv.create_text(7*self.case+self.case//2,5*self.case+self.case//3,text=str(self.estGagnee()),font=('arial',self.case//8,'bold'),fill="black" )
    

    def drawParking(self,cnv):
        img=Image.open(f'assets/fond_parquet.png')
        img=ImageTk.PhotoImage(img.convert("RGBA"))
        self.bg=img
        cnv.create_image(self.board_x,self.board_y,image=self.bg,anchor='nw')

    def draw(self,cnv):
        cnv.delete("all")
        self.drawGrille(cnv)
        #self.drawFleche(cnv)
        self.drawInfo(cnv)
        self.drawMenu(cnv)
        #self.drawParking(cnv)
        self.drawVehicules(cnv)

    
    def show(self):
        ''' utilitée principale du module_fenetre_partie avec gestion d'events'''

        def selection(event):
            global mouse
            mouse=True
            ''' si le click est dans la grille on met a jour l'id selected
                on met a jour origin_click
                et on redessin car la couleur du vehicule selected change '''
            self.origin_click=(event.x,event.y)
            self.vector_deplacement=(0,0)
            (i,j)=self.coordFrame_coordMatrice(event.x,event.y)
            if 0<=i<=5 and 0<=j<=5 and self.matrice[i][j]!=0:
                self.selected= self.matrice[i][j]
                self.selectedCoord=self.vehicules[self.selected].coord
                self.draw(cnv)
            
            
                
            

        def updateMove(event):
            ''' lorsque la souris bouge avec le click  gauche activé :
                on met a jour le vector_deplacement
                et on redessine'''
            self.vector_deplacement=(event.x-self.origin_click[0],event.y-self.origin_click[1])

            self.draw(cnv)
            

        def unselect(event):
            '''lorsqu'on lache le click gauche de la souris :
                    -on remet les attributs par defauts:
                    vector_deplacement,selected

                    -on met a jour la matrice selon le mouvement effectué

                    -on incrémente move
            '''
            if self.selected and self.selectedCoord!=self.vehicules[self.selected].coord :
                self.addMove()
                self.updateMatrice(self.vehicules[self.selected],self.selectedCoord)
                

            self.vector_deplacement=(0,0)
            self.selected=None
            self.draw(cnv)



        '''redimensionne le canvas par rapport a la fenetre 
        que lorsque l'on lache la souris pour éviter de traiter bcp '''
        def resize(event):

            if '<ButtonRelease-1>':
                W=root.winfo_width()
                H=root.winfo_height()
                self.width=W
                self.height=int(W*3/4)
                if self.height>H:
                    self.height=H
                    self.width=int(self.height*4/3)
                cnv.config(width=self.width,height=self.height)
                self.board_x=self.width//20
                self.board_y=self.height//40
                self.case=int(self.width/8.4)
                self.load_images()
                self.draw(cnv)
                    
                
        
        
        root=Tk()
        root.geometry(f'{self.width}x{self.height}+{root.winfo_screenwidth()//2-self.width//2}+{root.winfo_screenheight()//2-self.height//2}')
        root.minsize(400,300)
        cnv=Canvas(root,width=self.width,height=self.height,bg="palegoldenrod")
        cnv.pack(side="left",padx=0,pady=0)
        root.bind('<Button-1>',selection)
        root.bind('<B1-Motion>',updateMove)
        root.bind('<ButtonRelease-1>',unselect)
        root.title("Partie")
        cnv.bind('<Configure>',resize)
        self.load_images()
        self.draw(cnv)
        
        
        
        root.mainloop()


