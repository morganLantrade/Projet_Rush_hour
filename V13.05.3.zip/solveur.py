from partie import Partie 
from heapq import heappush, heappop
from copy import deepcopy
    


class Solveur():
    '''Pour solver la partie on prend la matrice de la partie actuelle
    on stocke dans une file a priorité les parties differentes issues de Partie.deplacements_possibles()
    comparées par le nombre de deplacements pour y arriver et selon nombre de deplacements qui sont possibles ensuite
    la premiere partie gagnante rencontrée sera forcement une solution optimale'''

    def __init__(self,matrice,sortie):
        self.partie=Partie(matrice,sortie)
        self.parties_a_tester=[]
        heappush(self.parties_a_tester,deepcopy(self.partie))
        self.parties_testees=set(self.partie.get_clé())
        self.solutions=[]

    

    def solver(self):
        if self.parties_a_tester[0].estGagnee():
            return []
        while self.parties_a_tester:
            next_partie=heappop(self.parties_a_tester)
            for d in next_partie.deplacements_possibles():
                next_partie.deplacer(d)
                if next_partie.estGagnee():
                    return next_partie.pile_deplacements
                    # return next_partie.pile_deplacements[:len(next_partie.pile_deplacements)//5+1]   option reduire nb indices                                                    # car faut pas tricher
                elif next_partie.get_clé() not in self.parties_testees: # a voir 
                    self.parties_testees.add(next_partie.get_clé())
                    heappush(self.parties_a_tester,deepcopy(next_partie))
                next_partie.retour_arriere()
        return []

            





    
