from tkinter import*
from gestion_son import Musique
from menu import* 


root=Tk()
Musique()
fenetre=FenetreMenuPrincipale(root)
fenetre.root.mainloop()


