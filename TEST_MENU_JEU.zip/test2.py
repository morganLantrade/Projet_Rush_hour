import tkinter as tk
from PIL import Image, ImageTk

class FenetreMenuPrincipale:
    def __init__(self, root=None,size=(800,600)):
        self.root = root
        self.canvas=tk.Canvas(root,width=800,height=600,borderwidth=0,bg="#f1f2ee")
        self.bg=None
        
        self.root.title("Rush Before 19 Hour")

        ### CENTRER LA FENETRE AU MILIEU DE L'ECRAN ###
        self.width=800
        self.height=600

        screen_width=root.winfo_screenwidth()
        screen_height=root.winfo_screenheight()
        x= (screen_width/2)-(self.width/2)
        y=(screen_height/2)-(self.height/2)
        self.root.geometry(f'{self.width}x{self.height}+{int(x)}+{int(y)}')
        self.root.minsize(800,600)

        #### BOUTON "ACCEDER AU NIVEAUX DE DIFFICULTE : Jouer" ##### 
        self.boutton_difficulte=None
        self.image_jouer=None

        JOUER_I = Image.open(r"JOUER.png")
        self.image_jouer = ImageTk.PhotoImage(JOUER_I, Image.ANTIALIAS)

        self.boutton_difficulte=tk.Button(self.canvas, image=self.image_jouer,borderwidth=0, bg="#f1f2ee",command=self.ouvrir_choix_diff)


        #### BOUTON "COMMENT JOUER" ##### 
        self.boutton_regles=None
        self.image_regles=None

        REGLES = Image.open(r"REGLES.png")
        self.image_regles = ImageTk.PhotoImage(REGLES, Image.ANTIALIAS)

        self.boutton_regles=tk.Button(self.canvas, image=self.image_regles,borderwidth=0,bg="#f1f2ee",
                  command=self.ouvrir_regles,cursor="question_arrow")


        ### BOUTON QUITTER LE JEU ###

        self.boutton_quitter=None
        self.root.protocol("WM_DELETE_WINDOW",self.quitter)

        QUITTER_I = Image.open(r"QUITTER.png")
        self.image_quitter = ImageTk.PhotoImage(QUITTER_I, Image.ANTIALIAS)

        self.boutton_quitter=tk.Button(self.canvas, image=self.image_quitter,borderwidth=0,bg="#f1f2ee",activebackground="#f1f2ee", #a2cce7
            command=self.quitter,cursor="X_cursor")
        
        #Mise en place du fond sur la fenêtre : 
        self.ouvrir_fond()
        #Creation des boutons sur la fenêtre : 

        self.canvas.create_window(400,300,window=self.boutton_difficulte,anchor="center")
        self.canvas.create_window(400,380,window=self.boutton_regles,anchor="center")
        self.canvas.create_window(400,460,window=self.boutton_quitter,anchor="center")
        self.canvas.pack()
        

    def ouvrir_fond(self):
        lien = r"menu_principal.png"
        self.bg = ImageTk.PhotoImage(Image.open(lien).resize((800,600),Image.ANTIALIAS))
        self.canvas.create_image(0,0,image=self.bg,anchor="nw")
        

    def aff_menu_principale(self):
        self.canvas.pack()

    def ouvrir_regles(self):
        self.menu_regles = Page_Regles(master=self.root, app=self)
        self.canvas.pack_forget()
        self.menu_regles.lancer_regles()

    def ouvrir_choix_diff(self):
        self.menu_diff = Page_Difficulte(master=self.root, app=self)
        self.canvas.pack_forget()
        self.menu_diff.lancer_diff()

    def quitter(self):
        self.root.destroy()


###############################################################################################################
#                   CLASSE DE LA PAGE GUIDANT LE JOUEUR SUR LES REGLES ET LES COMMANDES                     #
##############################################################################################################
class Page_Regles:
    def __init__(self, master=None, app=None):
        self.master = master
        self.app = app
        self.canva = tk.Canvas(self.master,borderwidth=0,width=800,height=600)
        self.bg=None



        #### BOUTON RETOUR AU MENU PRINCIPAL ###

        self.boutton_retour=None 
        self.image_retour=None 

        RETOUR= Image.open(r"RETOUR 1.png")
        self.image_retour= ImageTk.PhotoImage(RETOUR, Image.ANTIALIAS)
        self.boutton_retour=tk.Button(self.master, image=self.image_retour, borderwidth=0, command=self.retour_menu,activebackground="#f1f2ee")


        self.background()

        self.canva.create_window(400,550,window=self.boutton_retour,anchor="center")
        self.canva.pack()


    def background(self):
        lien = r"bg_regles.png"
        self.bg = ImageTk.PhotoImage(Image.open(lien).resize((800,600),Image.ANTIALIAS))
        self.canva.create_image(0,0,image=self.bg,anchor="nw")


    def lancer_regles(self):
        self.canva.pack()

    def retour_menu(self):
        self.canva.pack_forget()
        self.app.aff_menu_principale()



###############################################################################################################
#                   CLASSE DE LA PAGE DE CHOIX DE DIFFICULTE DES NIVEAUX DU JEU                             #
##############################################################################################################
class Page_Difficulte:
    def __init__(self, master=None, app=None):
        self.master = master
        self.app = app
        self.canva = tk.Canvas(self.master,borderwidth=0,width=800,height=600)
        self.bg=None



        #### BOUTON RETOUR AU MENU PRINCIPAL ###

        self.boutton_retour=None 
        self.image_retour=None 

        RETOUR= Image.open(r"RETOUR 1.png")
        self.image_retour= ImageTk.PhotoImage(RETOUR, Image.ANTIALIAS)
        self.boutton_retour=tk.Button(self.master, image=self.image_retour, borderwidth=0, command=self.retour_menu,activebackground="#f1f2ee")


        self.background()

        self.canva.create_window(400,550,window=self.boutton_retour,anchor="center")
        self.canva.pack()

    def background(self):
        lien = r"choix_diff.png"
        self.bcg = ImageTk.PhotoImage(Image.open(lien).resize((800,600),Image.ANTIALIAS))
        self.canva.create_image(0,0,image=self.bcg,anchor="nw")


    def lancer_diff(self):
        self.canva.pack()

    def retour_menu(self):
        self.canva.pack_forget()
        self.app.aff_menu_principale()







if __name__ == '__main__':
    root = tk.Tk()
    app = FenetreMenuPrincipale(root)
    root.mainloop()