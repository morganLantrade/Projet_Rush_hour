from tkinter import*
from gestion_son import Musique
from menu import* 


test=Tk()
Musique()
menu=FenetreMenuPrincipale(test)
menu.root.mainloop()


